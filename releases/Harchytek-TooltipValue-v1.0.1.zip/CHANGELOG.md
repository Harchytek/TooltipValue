## v1.0.1
* Updated to support the latest website layout and display changes.
* Added `TradersExtended` as a dependency.

## v1.0.0
* Initial release.